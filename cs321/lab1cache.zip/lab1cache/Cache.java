import java.util.NoSuchElementException;


/**
 * @author nik morales
 *
 * @param <T>
 */
public class Cache<T> implements ICache<T> 
{
	private int count;
	DLLNode<T> first, end; 
	private int modCount;
	
	
	public IUDoubleLinkedList<T> List = new IUDoubleLinkedList<T>();
	public double hit = 0, miss = 0;
	int size;

	/**
	 * Default
	 */
	public Cache()
	{
		count = 0;
		modCount = 0; 
		end = null;
		first = end; 
		
		
		size = 1000;
		List = new IUDoubleLinkedList<T>();
		
	}
	
	/**
	 * @param size
	 */
	public Cache(int size)
	{
		this.size = size;
		List = new IUDoubleLinkedList<T>();		
	}

	
	@Override
	public T get(T target) 
	{
		//in list with room
		if(List.contains(target)) 
		{
			hit++;
			write(target);
			return target;
		}
		//not in list
		miss++;
		return null;
	}

	@Override
	public void clear() 
	{
		for(int i = 0; i < List.size(); i++ )
		{
			List.removeFirst();
		}
	}

	@Override
	public void add(T data) 
	{

		DLLNode<T> newNode = new DLLNode<T>(element);
		int index = 0;

		if(isEmpty()){
			first = newNode;
			end = newNode;
		}
		else {
			DLLNode<T> current = first;
			while(index < (size()-1))
			{
				index++; 
				current.equals(current.getNext());
			}

			if (index == (size()-1)){
				current.setNext(newNode);
				current.setPrevious(null);
				newNode.setPrevious(current);
				first = newNode;
			}
		}
		count ++; 
		modCount++;

	}

	@Override
	public void removeLast() 
	{
		if(List.isEmpty()) 
		{
			throw new IllegalStateException("Cache is empty");
		}
		List.removeLast();
	}

	@Override
	public void remove(T target) 
	{
		if(List.contains(target)) 
		{
			List.remove(target);
		}
		else 
		{
			throw new NoSuchElementException("Target not found");
		}
		
	}
	
	
	@Override
	public void write(T data) 
	{
		if(List.contains(data)) 
		{
			remove(data);
			List.addToFront(data);
		}
		else {
			throw new NoSuchElementException("Data not in cache");
		}
		
	}
	
	public double getHits()
	{
		return hit;
	}
	
	public double getAcs()
	{
		double acs = hit + miss;
		return acs;
	}
	
	static public boolean isNaN(double v) {
	    return (v != v);
	}

	@Override
	public double getHitRate() 
	{
		double hitRate = Math.abs(hit/getAcs());
		if(isNaN(hitRate)) {
			hitRate = 0.0;
		}
		
		return hitRate;
	}

	@Override
	public double getMissRate() 
	{
		double missRate = 1 - getHitRate();
		return missRate;
	}

	@Override
	public boolean isEmpty() 
	{
		return List.isEmpty();
	}
	
}
