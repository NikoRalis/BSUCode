
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.text.DecimalFormat;
import java.util.Scanner;
import java.util.StringTokenizer;

public class CacheSimulator {

	public static String one = "1", two = "2" ;
	public static int size1 , size2;
	public static Cache<String> l1, l2;

	/**
	 * @param args
	 */
	public static void main(String[] args) throws FileNotFoundException {

		//TEST1
		if(args[0].equals(one) && args.length == 3){
			try {
				size1 = Integer.parseInt(args[1]);
			} catch (NumberFormatException e) {
				System.out.println("Size needs to be a int");
				e.printStackTrace();
			}

			File file = new File(args[2]);
			CacheSimulator1(file);
		}

		//TEST2
		else if(args[0].equals(two) && args.length == 4){

			try {
				size1 = Integer.parseInt(args[1]);
				size2 = Integer.parseInt(args[2]);

			} catch (NumberFormatException e) {
				System.out.println("Size needs to be a int");
				e.printStackTrace();
			}

			File file = new File(args[3]);
			CacheSimulator2(file);
		}

		//DEFAULT
		else if(args.length == 1){

			File file = new File(args[0]);
			size1 = 1000;
			Default(file);
		}
		else{
			System.err.println("Please enter a valid argument");
		}
	}

	/**
	 * @param file
	 */
	public static void CacheSimulator1(File file){

		try {
			Cache<String> l1 = new Cache<String>(size1);
			BufferedReader buf = new BufferedReader(new FileReader(file));
			Scanner FileScan = new Scanner(buf);
			System.out.println("L1 cache with " + size1 + " entries created.");
			System.out.println(". . . .");


			while(FileScan.hasNext())
			{
				String fileLine = FileScan.nextLine();
				StringTokenizer st = new StringTokenizer(fileLine," *!\t");

				while(st.hasMoreTokens())
				{
					String addString = st.nextToken();
					
					if(l1.get(addString) == null){
						l1.add(addString);
					}
					
				}


			}

			double L1HR = l1.getHitRate() * 100;
			int lhits = (int) l1.getHits();
			int lacs = (int) l1.getAcs();
			DecimalFormat f = new DecimalFormat("##.00");

			System.out.println("\nNumber of L1 hits: " + lhits);
			System.out.println("L1 Hit rate: " + f.format(L1HR)+ "%\n");
			System.out.println("Total number of accesses: " + lacs);
			System.out.println("Total number of hits: " + lhits);
			System.out.println("Overall hit rate: " + f.format(L1HR) + "%\n");

			FileScan.close();
		} 

		catch (FileNotFoundException e) {
			System.err.println("File not found");
			e.printStackTrace();
		}

	}

	public static void CacheSimulator2(File file)
	{

		try {
			Cache<String> l1 = new Cache<String>(size1);
			Cache<String> l2 = new Cache<String>(size2);

			BufferedReader buf = new BufferedReader(new FileReader(file));
			Scanner FileScan = new Scanner(buf);
			
			System.out.println("L1 cache with " + size1 + " entries created.");
			System.out.println("L2 cache with " + size2 + " entries created.");
			System.out.println(". . . .");




			while(FileScan.hasNextLine())
			{

				String fileLine = FileScan.nextLine();
				StringTokenizer st = new StringTokenizer(fileLine, " *!\t");

				while(st.hasMoreTokens())
				{

					String addString = st.nextToken();

					//if l1 has it
					if(l1.get(addString) != null) 
					{
						
						l2.write(addString);
					}
					else
					{	
						//if l2 has it
						if(l2.get(addString) != null)
						{
							l1.add(addString);
						}
						
						//if neither
						else
						{
							l1.add(addString);
							l2.add(addString);
						}
					}



				}


			}

			double L1HR = l1.getHitRate() * 100;
			int lhits = (int) l1.getHits();
			int lacs = (int) l1.getAcs();

			double L2HR = l2.getHitRate() * 100;
			int l2hits = (int) l2.getHits();
			int l2acs = (int) l2.getAcs();
			
			
			

			double HR = ((l1.getHits() + l2.getHits())/lacs) * 100;

			DecimalFormat f = new DecimalFormat("##.00");
			System.out.println("\nNumber of L1 hits: " + lhits);
			System.out.println("L1 Hit rate: " + f.format(L1HR)+ "%\n");
			System.out.println("\nNumber of L2 hits: " + l2hits);
			System.out.println("L2 Hit rate: " + f.format(L2HR)+ "%\n");
			System.out.println("Total number of accesses: " + (lacs + l2acs));
			System.out.println("Total number of hits: " + (lhits + l2hits));
			System.out.println("Overall hit rate: " + f.format(HR) + "%\n");
			
			FileScan.close();


		} 

		catch (FileNotFoundException e) {
			System.err.println("File not found");
			e.printStackTrace();
		}





	}

	public static void Default(File file){

		try {
			Cache<String> l1 = new Cache<String>(size1);
			BufferedReader buf = new BufferedReader(new FileReader(file));
			Scanner FileScan = new Scanner(buf);
			System.out.println("L1 cache with " + size1 + " entries created.");
			System.out.println(". . . .");


			while(FileScan.hasNext())
			{
				String fileLine = FileScan.nextLine();
				StringTokenizer st = new StringTokenizer(fileLine," *!\t");

				while(st.hasMoreTokens())
				{
					String addString = st.nextToken();
					
					if(l1.get(addString) == null){
						l1.add(addString);
					}
					
				}


			}

			double L1HR = l1.getHitRate() * 100;
			int lhits = (int) l1.getHits();
			int lacs = (int) l1.getAcs();
			DecimalFormat f = new DecimalFormat("##.00");

			System.out.println("\nNumber of L1 hits: " + lhits);
			System.out.println("L1 Hit rate: " + f.format(L1HR)+ "%\n");
			System.out.println("Total number of accesses: " + lacs);
			System.out.println("Total number of hits: " + lhits);
			System.out.println("Overall hit rate: " + f.format(L1HR) + "%\n");

			FileScan.close();
		} 

		catch (FileNotFoundException e) {
			System.err.println("File not found");
			e.printStackTrace();
		}

		
	}
}
