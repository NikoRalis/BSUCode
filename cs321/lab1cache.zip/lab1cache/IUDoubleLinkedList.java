
import java.util.NoSuchElementException;

/**
 * @author Nik Morales
 *
 * @param <T>
 */
public class IUDoubleLinkedList<T>{
	private int count;
	DLLNode<T> first, end; 
	private int modCount;

	public IUDoubleLinkedList()
	{
		count = 0;
		modCount = 0; 
		end = null;
		first = end; 
	}

	public void add(T element)
	{
		DLLNode<T> newNode = new DLLNode<T>(element);
		int index = 0;

		if(isEmpty()){
			first = newNode;
			end = newNode;
		}
		else {
			DLLNode<T> current = first;
			while(index < (size()-1))
			{
				index++; 
				current.equals(current.getNext());
			}

			if (index == (size()-1)){
				current.setNext(newNode);
				current.setPrevious(null);
				newNode.setPrevious(current);
				first = newNode;
			}
		}
		count ++; 
		modCount++;
	}


	public void add(int index, T element)
	{
		DLLNode<T> current = first;
		DLLNode<T> newNode = new DLLNode<T>(element);

		if(index < 0 || index > size())
		{
			throw new IndexOutOfBoundsException("IUDoubleLinkedList - add(index)");
		}

		if(index == 0 || isEmpty())
		{
			add(element);
		}
		else
		{
			DLLNode<T> previous = current.getPrevious();

			for(int i = 0; i < index; i++)
			{
				previous = current;
				current = current.getNext();
			}
			newNode.setNext(current);
			newNode.setPrevious(previous);

			previous.setNext(newNode);
			count++; 
			modCount++;
		}
	}

	public void addToFront(T element) {
		DLLNode<T> newNode = new DLLNode<T>(element);

		if(size()==0){
			first = newNode;
			end = newNode;
		}
		else {
			newNode.setNext(first);
			first.setPrevious(newNode);
			first = newNode;	
		}

		count ++; 
		modCount++;
	}


	public void addToRear(T element) {
		DLLNode<T> newNode = new DLLNode<T>(element);
		int index = 0;

		if (isEmpty()){
			first = newNode;
			end = newNode;
		}
		else{
			DLLNode<T> current = first;
			while(index < (size()-1))
			{
				index++; 
				current = current.getNext();
			}

			if (index == (size()-1)){
				current.setNext(newNode);
				newNode = end;

			}
		}

		count++;
		modCount++;

	}


	public void addAfter(T element, T target) {
		DLLNode<T> newNode = new DLLNode<T>(element);
		DLLNode<T> targetNode = new DLLNode<T>(target);
		DLLNode<T> current = first;

		boolean found = false;
		int index = 0;


		while(!found && index < (size()))
		{
			if(current.getElement() == target)
			{
				found = true;
				targetNode.setNext(newNode);
				count ++;
				modCount++;
			}
			else
			{
				index++; 
				current = current.getNext();
			}
		}

		if (index == (size()) && found == false){
			throw new NoSuchElementException("IUDoubleLinkedList - addAfter(T, T)");
		}
	}


	public T remove(T element)
	{
		DLLNode<T> current = first;

		boolean found = false;
		while(!found && current != null)
		{
			if(current.getElement().equals(element))
			{
				found = true;
			}
			else
			{
				current = current.getNext();
			}
		}
		if(!found)
		{
			throw new NoSuchElementException("IUDoubleLinkedList - remove");
		}

		if (size() == 1)
		{
			first = null;
			end = null;
		}
		
		else if (current == end){
			end = end.getPrevious();
			end.setNext(null);
		}
		else if (current == first){
			first =first.getNext();
			first.setPrevious(null);
		}
		else
		{
			current.getPrevious().setNext(current.getNext());
			current.getNext().setPrevious(current.getPrevious());
		}

		count--;
		modCount++; 
		return element;
	}


	public T remove(int index) {
		DLLNode<T> current = first;
		DLLNode<T> previous = null;
		DLLNode<T> previosPrev = null;
		DLLNode<T> returnVal = null;
		boolean flag = false;

		if(index < 0 || index >= size())
		{
			throw new IndexOutOfBoundsException("IUDoubleLinkedList - renive(index)");
		}
		if (isEmpty()){
			throw new IndexOutOfBoundsException("IUDounleLinkedList - renive(index)");
		}
		if (size() == 1){
			returnVal = first;
			first = null;
			end = null;
		}

		for(int i = 0; i <= index; i++)
		{
			if(i != 0){
				flag = true;
				previosPrev = previous;
			}
			previous = current;
			current = current.getNext();
		}
		if(index == 0)
		{
			first = current;
		}
		returnVal = previous;

		if(previous.getNext()!= null && flag)
		{
			previosPrev.setNext(previous.getNext());
		}
		previous.setNext(null);
		previous = null;
		count --; 
		modCount++;

		return returnVal.getElement();
	}


	public T removeFirst() {
		DLLNode<T> current = first;
		DLLNode<T> previous = null;
		DLLNode<T> returnVal = null;

		if(isEmpty()){
			throw new IllegalStateException("IUDoubleLinkedList - removeFirst()");
		}
		if(size() == 1){
			returnVal = first;
			first = null;
			end = null;
		}

		previous = current; 
		returnVal = previous;
		current = current.getNext();
		previous = null;
		first = current;
		count --; 
		modCount++;

		return returnVal.getElement();
	}


	public T removeLast() {
		DLLNode<T> returnVal = null;

		if(isEmpty()){
			throw new IllegalStateException("IUDoubleLinkedList - removeLast()");
		}
		if(size() == 1){
			returnVal = first;
			first = null;
			end = null;

		}

		else
		{
			returnVal = end;
			end = end.getPrevious();
			end.setNext(null);
			
		}
		count--; 
		modCount++;
		return returnVal.getElement();

	}


	public int indexOf(T element)
	{
		boolean found = false;
		int index = 0;
		DLLNode<T> current = first;
		while(!found && index < size())
		{
			if(current.getElement() == element)
			{
				found = true;
			}
			else
			{
				index++; 
				current = current.getNext();
			}
		}

		if(!found)
		{
			index = -1;
		}

		return index;	
	}

	public T get(int index)
	{
		if(index < 0 || index >= size())
		{
			throw new IndexOutOfBoundsException("IUDoubleLinkedList - get");
		}

		DLLNode<T> current = first;

		for(int i = 0; i < index; i++)
		{
			current = current.getNext();
		}
		return current.getElement();
	}


	public void set(int index, T element)
	{
		if(index < 0 || index >= size())
		{
			throw new IndexOutOfBoundsException("IUDoubleLinkedList - set");
		}

		DLLNode<T> current = first;

		for(int i = 0; i < index; i++)
		{
			current = current.getNext();
		}
		current.setElement(element);
		modCount++;
	}


	public int size()
	{
		return count;
	}


	public boolean isEmpty()
	{
		return (count == 0);
	}


	public T first() {
		if(isEmpty()){
			throw new IllegalStateException("IUDoubleLinkedList - first");
		}

		DLLNode<T> current = first;
		return current.getElement();
	}


	public T last() {
		if(isEmpty()){
			throw new IllegalStateException("IUDoubleLinkedList - last");
		}

		return get(size()-1);
	}


	public boolean contains(T target) {
		DLLNode<T> current = first;

		boolean found = false;
		while(!found && current != null)
		{
			if(current.getElement().equals(target))
			{
				found = true;
			}
			else
			{ 
				current = current.getNext();
			}
		}

		return found;
	}


}