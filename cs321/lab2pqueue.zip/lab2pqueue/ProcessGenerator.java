
public class ProcessGenerator {

	public ProcessGenerator(double probability) {
		// TODO Auto-generated constructor stub
	}

	public boolean query() {
		// TODO Auto-generated method stub
		return false;
	}

	public Process getNewProcess(int currentTime, int maxProcessTime, int maxLevel) {
		// TODO Auto-generated method stub
		return null;
	}

}
