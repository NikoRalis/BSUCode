
public class PQueue<T> {
	MaxHeap<T> maxHeap = new MaxHeap<T>();

	public PQueue(){
		
	}
	
	public PQueue(T[] maxHeap, int[] size){
		
	}

	public T maximum() {
		return null;
		
	}
	
	public T extractMax() {
		return null;
		
	}
	
	public void increastKey(int firstPos, int secPos) {
		
	}
	
	public void insert(T[] maxHeap, int pos){
		
	}
	
	public boolean isEmpty() {
		if (maxHeap.isEmpty()){
			return true;
		}
		return false;
	}

	//shouldnt be void?
	public void size(){
		
	}
}
