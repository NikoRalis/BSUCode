import java.util.NoSuchElementException;

public class MaxHeap<T>{

	HeapNode<T> heap;	
	int heapSize, capacity, head, tail;
	final int DEFAULT_CAPACITY = 50;
	private T[] heapArray;
	private int[] keys;

	public MaxHeap(){
		capacity = DEFAULT_CAPACITY;
		heapArray = (T[])(new Object[capacity]);
		keys = (new int[capacity]);
		head = tail = 0;
	}

	public MaxHeap(T[] newHeap, int newKeys[]){
		//HeapNode<T>[] heap = (HeapNode<T>[]) new HeapNode<?>[capacity];
		//heapArray = (T[]) heap;

		capacity = DEFAULT_CAPACITY;
		heapArray = newHeap.clone();
		keys = newKeys.clone();
		head = 0;
		heapSize = keys.length;
		tail = keys.length - 1;
		for (int i = heapSize / 2 - 1; i > 0; i--) {
			maxHeapify(i);
		}
	}

	public T heapMax(){
		if(heapSize>0) {
			return heapArray[head];
		} else {
			throw new NoSuchElementException();
		}
	}

	public T extractHeapMax() {

		T retval = heapMax();

		if(heapSize == 1) {
			heapArray[head] = null;
			keys[head] = 0;
		}
		else {
			heapArray[head] = heapArray[tail];
			keys[head] = keys[tail];
			heapArray[tail] = null;
			keys[tail] = 0;
		}

		if(head == capacity || head == heapSize) {
			head = 0;
		}

		heapSize--;
		for (int i = heapSize / 2 - 1; i >= 0; i--) {
			maxHeapify(i);
		}

		return retval;

	}

	public void increaseHeapKey(int parent ,int child)
	{
		int temp = parent;
		parent = child;
		child = temp;

	}

	public void maxHeapInsert(T newNode, int key){
		if (heapSize == capacity) {
			expandCapacity();
		}
		heapArray[heapSize] = newNode;
		keys[heapSize] = key;
		tail++;
		heapSize++;
	} 

	private void expandCapacity() {
		int newCap = DEFAULT_CAPACITY * 2;
		MaxHeap.this.capacity = newCap;

	}

	public void maxHeapify(int i){

		int largest = i;
		int l = left(i);
		int r = right(i);

		if(l <= heapSize && keys[l] > keys[i]) {
			largest = l;
		}

		if(r <= heapSize && keys[r] > keys[largest]){
			largest = r;
		}

		if(largest != i) {
			exchange(i, largest);
			maxHeapify(keys[i]);
		}

	}

	private void moveUp(int pos){
		keys[pos]++;
	}

	public int getHeapSize(){
		return heapSize;
	}

	public boolean isEmpty(){		
		boolean flag = false;

		if(heapSize == 0){
			flag = true;
		}

		return flag;

	}

	private void exchange(int parent, int child) {
		int temp = parent;
		keys[parent] = keys[child];
		keys[child] = temp;
		
	}

	private int left(int pos){
		int lChild;

		if (pos == head) {
			lChild = 1;
		}
		else lChild = (2 * pos);
		return lChild;
	}

	private int right(int pos){
		int rChild;
		if (pos == head) {
			rChild = 2;
		}
		else rChild = (2*pos)+1;
		return rChild;
	}

	private int parent(int pos){
		if(pos == head) {
			throw new NoSuchElementException();
		}
		int parent = ((pos - 1) / 2);

		return parent;
	}

	private void setHeapSize(int newHeapSize){
		heapSize = newHeapSize;

	}

	private void setCapacity(int newCap) {
		capacity = newCap;
	}

}
